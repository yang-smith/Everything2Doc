# Everything2Doc
turn chat records to docs
各种群聊的聊天记录里面包含着很多有价值的信息，但是这些信息是碎片化的，难以被利用。
该工具可以将群聊的聊天记录转换为结构化的文档，方便后续的利用。

